/*1)	Verificare che i campi definiti come PK siano univoci. 
/In altre parole, scrivi una query 
per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).*/
/*In fase di creazione del database le chiavi primarie sono state definite con l'attributo PRIMARY KEY AUTO_INCREMENT.
Le query riportate confrontano il totale numero di righe nella chiave primaria con i valori non duplicati,
in modo da poter verificare l'unicità dei valori.
*/
SELECT COUNT(Prodotto.Cod_Prodotto) AS Tot_Prodotti, COUNT(DISTINCT Prodotto.Cod_Prodotto) AS NoDup_Prodotto 
FROM Prodotto;
SELECT COUNT(Vendita.Cod_DocVendita) AS Tot_Vendita, COUNT(DISTINCT Vendita.Cod_DocVendita) AS NoDup_Vendita 
FROM Vendita;
SELECT COUNT(Regione.Cod_Regione) AS Tot_Regioni, COUNT(DISTINCT Regione.Cod_Regione) AS NoDup_Regione
FROM Regione;
SELECT COUNT(Stato.Cod_Stato) AS Tot_Stato, COUNT(DISTINCT Stato.Cod_Stato) AS NoDup_Stato
FROM Stato;
SELECT COUNT(Categoria.Cod_Categoria) AS Tot_Stato, COUNT(DISTINCT Categoria.Cod_Categoria) AS NoDup_Categoria
FROM Categoria;

/* 2)	Esporre l’elenco delle transazioni indicando nel result set 
il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, 
il nome della regione di vendita e un campo booleano valorizzato 
in base alla condizione che siano passati più di 180 giorni dalla 
data vendita o meno (>180 -> True, <= 180 -> False)*/
/* Dopo aver selezionato le colonne richieste nel result set, 
verifico tramite la funzione DATEDIFF se la differenza tra la data di vendita 
e la data attuale (CURDATE) supera i 180 giorni. 
Infine, applico utilizzo la funzione JOIN  per il recupero delle informazioni correlate.
*/
SELECT 
    Vendita.Cod_DocVendita AS Codice_Documento, 
    Vendita.Data_Vendita AS Data_Documento, 
    Prodotto.Nome_Prodotto AS Prodotto_Venduto, 
    Categoria.Nome_Categoria AS Categoria_Prodotto, 
    Stato.Nome_Stato AS Stato_Vendita, 
    Regione.Nome_Regione AS Regione_Vendita,
IF( DATEDIFF( CURDATE(), Vendita.Data_Vendita) > 180, 'True', 'False') AS Vendita_MesiPrecedenti
FROM Vendita 
JOIN Prodotto  ON Vendita.FK_Cod_Prodotto = Prodotto.Cod_Prodotto
JOIN Categoria  ON Prodotto.FK_Cod_Categoria = Categoria.Cod_Categoria
JOIN Regione  ON Vendita.FK_Cod_Regione = Regione.Cod_Regione
JOIN Stato ON Stato.FK_Cod_Regione = Regione.Cod_Regione;


/*3)	Esporre l’elenco dei prodotti che hanno venduto, in totale, 
una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
Nel result set devono comparire solo il codice prodotto e il totale venduto. */
/*La view Prodotti_Venduti si basa su una select dalla tabella Vendita composta da Cod_Prodotto e Quantita_Vendute,
viene eseguito un confronto tra gli anni delle vendite per verificare quelle attuate nell'ultimo anno, successivamente 
vengono raggruppate secondo il cod_prodotto.
La select successiva basata sulla view precedentemente creata analizza la quantità venduta, in base alla media.
*/
CREATE OR REPLACE VIEW Prodotti_Venduti AS
	SELECT Vendita.FK_Cod_Prodotto AS Cod_Prodotto, SUM(Vendita.Quantita_Vendita) AS Quantita_Vendute
	FROM Vendita
		WHERE YEAR(Vendita.Data_Vendita) = (SELECT MAX(YEAR(Vendita.Data_Vendita)) FROM Vendita)
	GROUP BY Vendita.FK_Cod_Prodotto;

	SELECT Cod_Prodotto, Quantita_Vendute
	FROM Prodotti_Venduti
	WHERE Quantita_Vendute > (SELECT AVG(Quantita_Vendute) FROM Prodotti_Venduti);
    
/*4)	Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. */
/* Con la select riesco ad estrapolare i dati richiesti, applico un join per il recupero delle info in condivisione
tra le due tabelle Vendita e Prodotto, li raggruppo secondo il nome e l'anno di vendita.
L'estrazione viene ordinata  per anno e fatturato */
SELECT 
    Prodotto.Nome_Prodotto, YEAR(Vendita.Data_Vendita) AS Anno,  
    SUM(Vendita.Quantita_Vendita * Prodotto.Prezzo_Prodotto) AS Totale_Vendita
FROM Prodotto
JOIN Vendita  ON Vendita.FK_Cod_Prodotto = Prodotto.Cod_Prodotto
GROUP BY Prodotto.Nome_Prodotto, YEAR(Vendita.Data_Vendita);

/*5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente*/
/* Con la query seleziono il nome dello stato, l'anno e il fatturato totale. Con il join recupero tutte le info.
raggruppo per stato e anno. applico un ordine crescente su anno e decrescente su fatturato.
*/
SELECT 
    Stato.Nome_Stato, 
    YEAR(Vendita.Data_Vendita) AS Anno, 
    SUM(Vendita.Quantita_Vendita * Prodotto.Prezzo_Prodotto) AS Fatturato_Totale
FROM Vendita
JOIN Prodotto ON Vendita.FK_Cod_Prodotto = Prodotto.Cod_Prodotto
JOIN Regione  ON Vendita.FK_Cod_Regione = Regione.Cod_Regione
JOIN Stato ON Stato.FK_Cod_Regione = Regione.Cod_Regione
GROUP BY Stato.Nome_Stato, YEAR(Vendita.Data_Vendita)
ORDER BY Anno ASC, Fatturato_Totale DESC;


/* 6)	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? */
/*Seleziono il nome della categoria e recupero le quantità vendute.
unisco le info con la funzione join e le raggruppo secondo il nome della categoria
raggruppo i risultati delle somme delle vendite per quantità e analizzo 
Recupero dalla subquery il valore massimo della somma totale delle quantità di vendita.
*/
SELECT 
    Categoria.Nome_Categoria, 
    SUM(Vendita.Quantita_Vendita) AS Pezzi_Venduti
FROM Vendita
JOIN Prodotto ON Vendita.FK_Cod_Prodotto = Prodotto.Cod_Prodotto
JOIN Categoria ON Prodotto.FK_Cod_Categoria = Categoria.Cod_Categoria
GROUP BY Categoria.Nome_Categoria
HAVING SUM(Vendita.Quantita_Vendita) >= ALL 
							(
								SELECT SUM(Vendita.Quantita_Vendita)
									FROM Vendita 
								JOIN Prodotto ON Vendita.FK_Cod_Prodotto = Prodotto.Cod_Prodotto
								GROUP BY Prodotto.FK_Cod_Categoria
							);
                
/*7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.*/
/* con la sottoquery crea un elenco univocodi tutti i codici prodotto della tabella Vendita.
   dalla query principale seleziona i nomi dalla tabella Prodotto, ma solo per quei record 
   il cui codice non compare nell'elenco.
*/
/* Opzione1 */
SELECT Prodotto.Nome_Prodotto
FROM Prodotto
WHERE Prodotto.Cod_Prodotto NOT IN 
	(
		SELECT DISTINCT Vendita.FK_Cod_Prodotto 
		FROM Vendita
	);
/* Opzione2 */   
SELECT Prodotto.Nome_Prodotto
FROM Prodotto
LEFT JOIN Vendita ON Prodotto.Cod_Prodotto = Vendita.FK_Cod_Prodotto
WHERE Vendita.FK_Cod_Prodotto IS NULL;

/*8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili 
(codice prodotto, nome prodotto, nome categoria)*/
CREATE VIEW Vista_Prodotti_Dettaglio AS
	SELECT 
		Prodotto.Cod_Prodotto, 
		Prodotto.Nome_Prodotto, 
		Categoria.Nome_Categoria
	FROM Prodotto
	JOIN Categoria ON Prodotto.FK_Cod_Categoria = Categoria.Cod_Categoria;
SELECT * FROM Vista_Prodotti_Dettaglio;

/*9)	Creare una vista per le informazioni geografiche*/
CREATE VIEW Vista_Geografica AS
SELECT 
    Regione.Cod_Regione, 
    Regione.Nome_Regione, 
    Stato.Nome_Stato
FROM Regione
JOIN Stato ON Stato.FK_Cod_Regione = Regione.Cod_Regione;
SELECT * FROM Vista_Geografica;
