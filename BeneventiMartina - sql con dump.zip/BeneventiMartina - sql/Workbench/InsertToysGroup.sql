/* Insert per le varie tabelle*/
/* Non ho inserito i codici chiave primaria manualmente negli INSERT perchè in fase di creazione
la clausola AUTO_INCREMENT incrementa in automatico.*/
INSERT INTO Categoria (Nome_Categoria) VALUES 
('Bikes'),
('Clothing'),
('Accessories');

INSERT INTO Regione (Nome_Regione) VALUES 
('SouthEurope'),
('WestEurope'),
('NorthAmerica');

INSERT INTO Stato (Nome_Stato, FK_Cod_Regione) VALUES 
('Italy', 1),
('Greece', 1),
('France', 2),
('Germany', 2),
('USA', 3);

INSERT INTO Prodotto (Nome_Prodotto, Descrizione_Prodotto, Prezzo_Prodotto, FK_Cod_Categoria) VALUES 
('Bikes-100', 'Mountain Bike entry level', 500.00, 1),
('Bikes-200', 'Road Bike professionale', 750.00, 1),
('Bike Glove M', 'Guanti misura M', 25.00, 2),
('Bike Glove L', 'Guanti misura L', 25.00, 2),
('Water Bottle', 'Borraccia sportiva 750ml', 10.00, 3);

INSERT INTO Vendita (Data_Vendita, Note_Vendita, Quantita_Vendita, FK_Cod_Prodotto, FK_Cod_Regione) VALUES 
('2025-01-10', 'Vendita Standard', 2, 1, 1),
('2025-08-15', 'Nota Tecnica', 5, 3, 1),
('2025-09-01', 'Online Store', 1, 2, 2),
('2025-12-10', 'Promo Natale', 10, 4, 2),
('2026-01-05', 'Promo Inverno', 3, 1, 1);