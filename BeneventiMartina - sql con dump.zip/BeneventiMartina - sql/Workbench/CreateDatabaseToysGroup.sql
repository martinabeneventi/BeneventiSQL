/* Creazione database*/
CREATE DATABASE IF NOT EXISTS ToysGroup;
USE ToysGroup;
/* Pulizia tabelle precedentemente utilizzate*/
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS Stato, Vendita, Prodotto, Regione, Categoria;
SET FOREIGN_KEY_CHECKS = 1;

/* Creazione tabelle*/
CREATE TABLE Categoria
(	
	Cod_Categoria int PRIMARY KEY AUTO_INCREMENT,
    Nome_Categoria  VARCHAR(50) NOT NULL
);

CREATE TABLE Regione
(
	Cod_Regione int PRIMARY KEY AUTO_INCREMENT,
    Nome_Regione VARCHAR(50) NOT NULL
);

CREATE TABLE Prodotto
(
	Cod_Prodotto int PRIMARY KEY AUTO_INCREMENT,
	Nome_Prodotto VARCHAR(50) NOT NULL,
	Descrizione_Prodotto VARCHAR(50) NOT NULL,
	Prezzo_Prodotto DECIMAL(10,2) NOT NULL,
    FK_Cod_Categoria INT NOT NULL,
    CONSTRAINT FK_Prodotto_Categoria
    FOREIGN KEY (FK_Cod_Categoria) REFERENCES Categoria(Cod_Categoria)
);

CREATE TABLE Vendita
( 
	Cod_DocVendita int PRIMARY KEY AUTO_INCREMENT,
    Data_Vendita DATE NOT NULL,
    Note_Vendita VARCHAR(50) NOT NULL,
    Quantita_Vendita INT NOT NULL,
    FK_Cod_Prodotto INT NOT NULL,
	FK_Cod_Regione INT NOT NULL,
    CONSTRAINT FK_Vendita_Prodotto
    FOREIGN KEY (FK_Cod_Prodotto) REFERENCES Prodotto(Cod_Prodotto),
    CONSTRAINT FK_Vendita_Regione
    FOREIGN KEY (FK_Cod_Regione) REFERENCES Regione(Cod_Regione)
);

CREATE TABLE Stato
(	
	Cod_Stato int PRIMARY KEY AUTO_INCREMENT,
    Nome_Stato  VARCHAR(50) NOT NULL,
    FK_Cod_Regione INT NOT NULL,
    CONSTRAINT FK_Stato_Regione
    FOREIGN KEY (FK_Cod_Regione) REFERENCES Regione(Cod_Regione)
);









