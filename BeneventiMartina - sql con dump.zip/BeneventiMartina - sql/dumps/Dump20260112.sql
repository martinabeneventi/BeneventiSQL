-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: toysgroup
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria` (
  `Cod_Categoria` int NOT NULL AUTO_INCREMENT,
  `Nome_Categoria` varchar(50) NOT NULL,
  PRIMARY KEY (`Cod_Categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'Bikes'),(2,'Clothing'),(3,'Accessories'),(4,'Bikes'),(5,'Clothing'),(6,'Accessories'),(7,'Bikes'),(8,'Clothing'),(9,'Accessories');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `prodotti_venduti`
--

DROP TABLE IF EXISTS `prodotti_venduti`;
/*!50001 DROP VIEW IF EXISTS `prodotti_venduti`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `prodotti_venduti` AS SELECT 
 1 AS `Cod_Prodotto`,
 1 AS `Quantita_Vendute`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `prodotto`
--

DROP TABLE IF EXISTS `prodotto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prodotto` (
  `Cod_Prodotto` int NOT NULL AUTO_INCREMENT,
  `Nome_Prodotto` varchar(50) NOT NULL,
  `Descrizione_Prodotto` varchar(50) NOT NULL,
  `Prezzo_Prodotto` decimal(10,2) NOT NULL,
  `FK_Cod_Categoria` int NOT NULL,
  PRIMARY KEY (`Cod_Prodotto`),
  KEY `FK_Prodotto_Categoria` (`FK_Cod_Categoria`),
  CONSTRAINT `FK_Prodotto_Categoria` FOREIGN KEY (`FK_Cod_Categoria`) REFERENCES `categoria` (`Cod_Categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prodotto`
--

LOCK TABLES `prodotto` WRITE;
/*!40000 ALTER TABLE `prodotto` DISABLE KEYS */;
INSERT INTO `prodotto` VALUES (1,'Bikes-100','Mountain Bike entry level',500.00,1),(2,'Bikes-200','Road Bike professionale',750.00,1),(3,'Bike Glove M','Guanti misura M',25.00,2),(4,'Bike Glove L','Guanti misura L',25.00,2),(5,'Water Bottle','Borraccia sportiva 750ml',10.00,3),(6,'Bikes-100','Mountain Bike entry level',500.00,1),(7,'Bikes-200','Road Bike professionale',750.00,1),(8,'Bike Glove M','Guanti misura M',25.00,2),(9,'Bike Glove L','Guanti misura L',25.00,2),(10,'Water Bottle','Borraccia sportiva 750ml',10.00,3),(11,'Bikes-100','Mountain Bike entry level',500.00,1),(12,'Bikes-200','Road Bike professionale',750.00,1),(13,'Bike Glove M','Guanti misura M',25.00,2),(14,'Bike Glove L','Guanti misura L',25.00,2),(15,'Water Bottle','Borraccia sportiva 750ml',10.00,3);
/*!40000 ALTER TABLE `prodotto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regione`
--

DROP TABLE IF EXISTS `regione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `regione` (
  `Cod_Regione` int NOT NULL AUTO_INCREMENT,
  `Nome_Regione` varchar(50) NOT NULL,
  PRIMARY KEY (`Cod_Regione`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regione`
--

LOCK TABLES `regione` WRITE;
/*!40000 ALTER TABLE `regione` DISABLE KEYS */;
INSERT INTO `regione` VALUES (1,'SouthEurope'),(2,'WestEurope'),(3,'NorthAmerica'),(4,'SouthEurope'),(5,'WestEurope'),(6,'NorthAmerica'),(7,'SouthEurope'),(8,'WestEurope'),(9,'NorthAmerica');
/*!40000 ALTER TABLE `regione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stato`
--

DROP TABLE IF EXISTS `stato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stato` (
  `Cod_Stato` int NOT NULL AUTO_INCREMENT,
  `Nome_Stato` varchar(50) NOT NULL,
  `FK_Cod_Regione` int NOT NULL,
  PRIMARY KEY (`Cod_Stato`),
  KEY `FK_Stato_Regione` (`FK_Cod_Regione`),
  CONSTRAINT `FK_Stato_Regione` FOREIGN KEY (`FK_Cod_Regione`) REFERENCES `regione` (`Cod_Regione`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stato`
--

LOCK TABLES `stato` WRITE;
/*!40000 ALTER TABLE `stato` DISABLE KEYS */;
INSERT INTO `stato` VALUES (1,'Italy',1),(2,'Greece',1),(3,'France',2),(4,'Germany',2),(5,'USA',3),(6,'Italy',1),(7,'Greece',1),(8,'France',2),(9,'Germany',2),(10,'USA',3),(11,'Italy',1),(12,'Greece',1),(13,'France',2),(14,'Germany',2),(15,'USA',3);
/*!40000 ALTER TABLE `stato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendita`
--

DROP TABLE IF EXISTS `vendita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendita` (
  `Cod_DocVendita` int NOT NULL AUTO_INCREMENT,
  `Data_Vendita` date NOT NULL,
  `Note_Vendita` varchar(50) NOT NULL,
  `Quantita_Vendita` int NOT NULL,
  `FK_Cod_Prodotto` int NOT NULL,
  `FK_Cod_Regione` int NOT NULL,
  PRIMARY KEY (`Cod_DocVendita`),
  KEY `FK_Vendita_Prodotto` (`FK_Cod_Prodotto`),
  KEY `FK_Vendita_Regione` (`FK_Cod_Regione`),
  CONSTRAINT `FK_Vendita_Prodotto` FOREIGN KEY (`FK_Cod_Prodotto`) REFERENCES `prodotto` (`Cod_Prodotto`),
  CONSTRAINT `FK_Vendita_Regione` FOREIGN KEY (`FK_Cod_Regione`) REFERENCES `regione` (`Cod_Regione`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendita`
--

LOCK TABLES `vendita` WRITE;
/*!40000 ALTER TABLE `vendita` DISABLE KEYS */;
INSERT INTO `vendita` VALUES (1,'2025-01-10','Vendita Standard',2,1,1),(2,'2025-08-15','Nota Tecnica',5,3,1),(3,'2025-09-01','Online Store',1,2,2),(4,'2025-12-10','Promo Natale',10,4,2),(5,'2026-01-05','Promo Inverno',3,1,1),(6,'2025-01-10','Vendita Standard',2,1,1),(7,'2025-08-15','Nota Tecnica',5,3,1),(8,'2025-09-01','Online Store',1,2,2),(9,'2025-12-10','Promo Natale',10,4,2),(10,'2026-01-05','Promo Inverno',3,1,1);
/*!40000 ALTER TABLE `vendita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vista_geografica`
--

DROP TABLE IF EXISTS `vista_geografica`;
/*!50001 DROP VIEW IF EXISTS `vista_geografica`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_geografica` AS SELECT 
 1 AS `Cod_Regione`,
 1 AS `Nome_Regione`,
 1 AS `Nome_Stato`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_prodotti_dettaglio`
--

DROP TABLE IF EXISTS `vista_prodotti_dettaglio`;
/*!50001 DROP VIEW IF EXISTS `vista_prodotti_dettaglio`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_prodotti_dettaglio` AS SELECT 
 1 AS `Cod_Prodotto`,
 1 AS `Nome_Prodotto`,
 1 AS `Nome_Categoria`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `prodotti_venduti`
--

/*!50001 DROP VIEW IF EXISTS `prodotti_venduti`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `prodotti_venduti` AS select `vendita`.`FK_Cod_Prodotto` AS `Cod_Prodotto`,sum(`vendita`.`Quantita_Vendita`) AS `Quantita_Vendute` from `vendita` where (year(`vendita`.`Data_Vendita`) = (select max(year(`vendita`.`Data_Vendita`)) from `vendita`)) group by `vendita`.`FK_Cod_Prodotto` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_geografica`
--

/*!50001 DROP VIEW IF EXISTS `vista_geografica`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_geografica` AS select `regione`.`Cod_Regione` AS `Cod_Regione`,`regione`.`Nome_Regione` AS `Nome_Regione`,`stato`.`Nome_Stato` AS `Nome_Stato` from (`regione` join `stato` on((`stato`.`FK_Cod_Regione` = `regione`.`Cod_Regione`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_prodotti_dettaglio`
--

/*!50001 DROP VIEW IF EXISTS `vista_prodotti_dettaglio`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_prodotti_dettaglio` AS select `prodotto`.`Cod_Prodotto` AS `Cod_Prodotto`,`prodotto`.`Nome_Prodotto` AS `Nome_Prodotto`,`categoria`.`Nome_Categoria` AS `Nome_Categoria` from (`prodotto` join `categoria` on((`prodotto`.`FK_Cod_Categoria` = `categoria`.`Cod_Categoria`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-12 17:39:05
